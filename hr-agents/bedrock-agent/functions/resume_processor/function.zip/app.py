import json
import os
import boto3
import uuid
import time
import logging
from datetime import datetime
from urllib.parse import unquote_plus

# Configure logging
logger = logging.getLogger()
logger.setLevel(os.environ.get('LOG_LEVEL', 'INFO'))

# Initialize clients
s3_client = boto3.client('s3')
bedrock_agent_runtime = boto3.client('bedrock-agent-runtime')
dynamodb = boto3.resource('dynamodb')

def lambda_handler(event, context):
    """
    Process resume uploads and invoke the Supervisor Agent for multi-agent evaluation.
    """
    logger.info(f"Received event: {json.dumps(event)}")
    
    try:
        # Handle S3 event
        if 'Records' in event:
            for record in event['Records']:
                bucket = record['s3']['bucket']['name']
                key = unquote_plus(record['s3']['object']['key'])
                
                # Only process files in the resumes/ prefix
                if not key.startswith('resumes/'):
                    logger.info(f"Skipping file not in resumes/ prefix: {key}")
                    continue
                
                process_resume(bucket, key)
        
        # Handle direct invocation
        elif 'resume_key' in event:
            bucket = event.get('bucket', os.environ.get('DOCUMENTS_BUCKET'))
            key = event['resume_key']
            process_resume(bucket, key)
        
        return {
            'statusCode': 200,
            'body': json.dumps('Resume processing completed successfully')
        }
        
    except Exception as e:
        logger.error(f"Error processing resume: {str(e)}")
        raise e

def process_resume(bucket, resume_key):
    """
    Process a single resume by invoking the Supervisor Agent.
    """
    # Generate unique candidate ID
    candidate_id = str(uuid.uuid4())
    
    # Read resume content
    resume_response = s3_client.get_object(Bucket=bucket, Key=resume_key)
    resume_text = resume_response['Body'].read().decode('utf-8')
    
    # Read job description
    job_key = 'jobs/ai_engineer_position.txt'
    try:
        job_response = s3_client.get_object(Bucket=bucket, Key=job_key)
        job_description = job_response['Body'].read().decode('utf-8')
    except Exception as e:
        logger.warning(f"Could not read job description from {job_key}: {str(e)}")
        job_description = "AI Engineer position - please analyze against general AI/ML requirements"
    
    # Extract candidate name from filename
    filename = resume_key.split('/')[-1]
    candidate_name = filename.replace('.txt', '').replace('_', ' ').title()
    
    # Create initial candidate record
    create_initial_candidate_record(candidate_id, candidate_name, resume_key, resume_text)
    
    # Prepare input for the Supervisor Agent
    agent_input = f"""
    Please evaluate this candidate for the AI Engineer position using multi-agent collaboration.
    
    Candidate ID: {candidate_id}
    Candidate Name: {candidate_name}
    
    RESUME:
    {resume_text}
    
    JOB DESCRIPTION:
    {job_description}
    
    Please coordinate with all specialized agents to provide a comprehensive evaluation including:
    1. Resume parsing and information extraction (ResumeParserAgent)
    2. Job requirements analysis (JobAnalyzerAgent)
    3. Detailed resume evaluation (ResumeEvaluatorAgent)
    4. Candidate rating (1-5 scale) (CandidateRaterAgent)
    
    Provide your final response as a comprehensive JSON structure containing all evaluation results.
    """
    
    logger.info(f"📝 Created initial candidate record for {candidate_id}")
    logger.info(f"🔍 AGENT INPUT DEBUG for {candidate_name}:")
    logger.info(f"📄 Resume length: {len(resume_text)} characters")
    logger.info(f"📋 Job description length: {len(job_description)} characters")
    logger.info(f"📝 Resume preview (first 200 chars): {resume_text[:200]}...")
    logger.info(f"💼 Job description preview (first 200 chars): {job_description[:200]}...")
    logger.info(f"🤖 Full agent input length: {len(agent_input)} characters")
    
    # Use the Supervisor Agent for multi-agent coordination
    agent_id = os.environ.get('SUPERVISOR_AGENT_ID')
    agent_alias_id = os.environ.get('SUPERVISOR_AGENT_ALIAS_ID')
    
    if not agent_id or not agent_alias_id:
        raise ValueError("Missing agent configuration")
    
    # Invoke the Supervisor Agent with retry logic
    logger.info(f"Invoking Supervisor Agent {agent_id}/{agent_alias_id} for resume: {resume_key}")
    
    session_id = str(uuid.uuid4())
    max_retries = 2
    
    for attempt in range(max_retries + 1):
        try:
            logger.info(f"🚀 Bedrock Agent Invocation Attempt {attempt + 1}:")
            logger.info(f"   Agent ID: {agent_id}")
            logger.info(f"   Agent Alias ID: {agent_alias_id}")
            logger.info(f"   Session ID: {session_id}")
            logger.info(f"   Input Text Length: {len(agent_input)}")
            
            response = bedrock_agent_runtime.invoke_agent(
                agentId=agent_id,
                agentAliasId=agent_alias_id,
                sessionId=session_id,
                inputText=agent_input,
                enableTrace=True
            )
            
            logger.info(f"✅ Bedrock Agent Response Received:")
            logger.info(f"   Response Keys: {list(response.keys())}")
            
            # Process the response
            response_text = ""
            chunk_count = 0
            if 'completion' in response:
                for event in response['completion']:
                    chunk_count += 1
                    logger.info(f"📦 Processing chunk {chunk_count}: {list(event.keys())}")
                    
                    # Enable trace logging for debugging
                    if 'trace' in event:
                        trace_data = event['trace']
                        logger.info(f"🔍 TRACE {chunk_count}: {json.dumps(trace_data, default=str)}")
                    
                    if 'chunk' in event:
                        chunk = event['chunk']
                        if 'bytes' in chunk:
                            chunk_text = chunk['bytes'].decode('utf-8')
                            response_text += chunk_text
            
            logger.info(f"Supervisor Agent response for {resume_key}:")
            logger.info(response_text)
            
            # Save the evaluation to DynamoDB
            save_evaluation_to_db(candidate_id, candidate_name, resume_key, resume_text, response_text)
            logger.info(f"💾 Successfully saved comprehensive evaluation for candidate {candidate_id} to DynamoDB")
            
            # Success - break out of retry loop
            break
            
        except Exception as e:
            if attempt < max_retries:
                logger.warning(f"Attempt {attempt + 1} failed: {str(e)}. Retrying...")
                time.sleep(5)  # Wait before retry
            else:
                logger.error(f"All attempts failed for {resume_key}: {str(e)}")
                # Save a basic record even if agent fails
                save_evaluation_to_db(candidate_id, candidate_name, resume_key, resume_text, f"Error: {str(e)}")
                raise e

def save_evaluation_to_db(candidate_id, candidate_name, resume_key, resume_text, evaluation_response):
    """
    Save the comprehensive evaluation results to DynamoDB.
    """
    table_name = os.environ.get('CANDIDATES_TABLE')
    table = dynamodb.Table(table_name)
    
    # Parse the evaluation response to extract structured components
    evaluation_data = parse_evaluation_response(evaluation_response)
    
    # Create comprehensive candidate record
    candidate_item = {
        'id': candidate_id,
        'name': candidate_name,
        'resume_key': resume_key,
        'resume_text': resume_text,
        'status': 'completed',
        'evaluation_results': evaluation_data.get('evaluation_results', {}),
        'gaps_analysis': evaluation_data.get('gaps_analysis', {}),
        'candidate_rating': evaluation_data.get('candidate_rating', {}),
        'interview_notes': evaluation_data.get('interview_notes', {}),
        'completed_at': datetime.utcnow().isoformat(),
        'job_title': 'AI Engineer',
        'evaluated_by': 'bedrock-agent-multiagent',
        'raw_evaluation_response': evaluation_response
    }
    
    # Save to DynamoDB
    table.put_item(Item=candidate_item)

def parse_evaluation_response(evaluation_response):
    """
    Parse the multi-agent evaluation response into structured components.
    """
    import re
    import json

    logger.info(f"🔍 Parsing evaluation response: {len(evaluation_response)} characters")
    logger.info(f"📝 Response preview: {evaluation_response[:500]}...")

    # First try to extract JSON from <result> tags
    result_match = re.search(r'<result>\s*({.*?})\s*</result>', evaluation_response, re.DOTALL)
    if result_match:
        try:
            json_str = result_match.group(1)
            logger.info(f"✅ Found JSON in <result> tags: {len(json_str)} characters")

            # Fix placeholder arrays like [...] that break JSON parsing
            json_str = re.sub(r'\[\.\.\.]', '[]', json_str)
            json_str = re.sub(r'\{\.\.\.\.\}', '{}', json_str)

            evaluation_json = json.loads(json_str)
            logger.info(f"✅ Successfully parsed JSON with placeholders fixed")
            return extract_structured_components(evaluation_json, evaluation_response)
        except json.JSONDecodeError as e:
            logger.warning(f"❌ Failed to parse JSON from <result> tags: {str(e)}")
            logger.warning(f"📄 JSON preview: {json_str[:500]}...")

    # Try to find JSON blocks that start with { and have balanced braces
    # Look for complete JSON objects with proper nesting
    json_patterns = [
        r'\{(?:[^{}]|(?:\{[^{}]*\}))*\}',  # Simple nested objects
        r'\{[^{}]*(?:\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}[^{}]*)*\}',  # More complex nesting
        r'\{.*?\}',  # Fallback greedy match
    ]

    all_json_candidates = []
    for pattern in json_patterns:
        matches = re.findall(pattern, evaluation_response, re.DOTALL)
        all_json_candidates.extend(matches)

    # Remove duplicates and sort by length (largest first)
    unique_candidates = list(set(all_json_candidates))

    for json_candidate in sorted(unique_candidates, key=len, reverse=True):
        try:
            logger.info(f"🔍 Trying JSON candidate: {len(json_candidate)} characters")
            logger.info(f"📄 JSON preview: {json_candidate[:200]}...")

            # Clean up common JSON issues
            cleaned_json = json_candidate.strip()
            # Fix placeholder arrays like [...] that break JSON parsing
            cleaned_json = re.sub(r'\[\.\.\.+\]', '[]', cleaned_json)
            cleaned_json = re.sub(r'\{\.\.\.+\}', '{}', cleaned_json)

            evaluation_json = json.loads(cleaned_json)

            # Validate it has the expected structure from our agents
            if (isinstance(evaluation_json, dict) and (
                'resumeParsingResults' in evaluation_json or
                'jobRequirementsAnalysis' in evaluation_json or
                'candidateRating' in evaluation_json or
                'resumeEvaluation' in evaluation_json or
                len(evaluation_json) >= 2)):  # Must have at least 2 fields for multi-agent response
                logger.info(f"✅ Successfully parsed structured JSON with {len(evaluation_json)} top-level fields")
                return extract_structured_components(evaluation_json, evaluation_response)

        except json.JSONDecodeError as e:
            logger.info(f"❌ JSON parsing failed: {str(e)}")
            continue

    logger.warning(f"❌ No valid JSON found, using text parsing")
    # If no valid JSON found, return minimal structure with actual text content
    return create_structured_from_text(evaluation_response)

def extract_structured_components(evaluation_json, raw_response):
    """
    Extract structured components from JSON evaluation response using ACTUAL agent data.
    """
    # Extract actual data from the specialized agents
    resume_parsing = evaluation_json.get('resumeParsingResults', {})
    job_analysis = evaluation_json.get('jobRequirementsAnalysis', {})
    resume_evaluation = evaluation_json.get('resumeEvaluation', {})
    candidate_rating = evaluation_json.get('candidateRating', {})
    interview_questions = evaluation_json.get('interviewQuestions', {})

    # Use ACTUAL data from agents instead of hardcoded mappings
    return {
        'evaluation_results': {
            'skills_summary': {
                'technical_skills': resume_parsing.get('technicalSkills', {}),
                'required_skills_match': job_analysis.get('requiredSkills', []),
                'preferred_qualifications_match': job_analysis.get('preferredSkills', [])
            },
            'technical_expertise': {
                'depth': extract_from_evaluation(resume_evaluation, 'technical depth'),
                'examples': [exp.get('responsibilities', []) for exp in resume_parsing.get('workExperience', [])]
            },
            'education_summary': {
                'alignment': extract_from_evaluation(resume_evaluation, 'education'),
                'details': [resume_parsing.get('education', {})] if resume_parsing.get('education') else []
            },
            'experience_summary': {
                'relevance': extract_from_evaluation(resume_evaluation, 'experience'),
                'details': resume_parsing.get('workExperience', [])
            },
            'job_match_analysis': {
                'skills_match': assess_skill_level(resume_evaluation, 'skills'),
                'experience_relevance': assess_skill_level(resume_evaluation, 'experience'),
                'education_fit': assess_skill_level(resume_evaluation, 'education'),
                'project_relevance': assess_skill_level(resume_evaluation, 'projects'),
                'overall_assessment': resume_evaluation.get('overallAssessment', '')
            },
            'raw_evaluation': raw_response,
            'job_title': 'AI Engineer'
        },
        'gaps_analysis': {
            'evaluation': {
                'missing_skills': extract_missing_skills_from_weaknesses(resume_evaluation.get('weaknesses', [])),
                'skill_gaps': extract_skill_gaps(job_analysis.get('required_skills', []), resume_parsing.get('technicalSkills', {})),
                'strengths': resume_evaluation.get('strengths', []),
                'recommendations': extract_actual_recommendations(resume_evaluation.get('overallAssessment', ''), resume_evaluation.get('weaknesses', []))
            }
        },
        'candidate_rating': {
            'overall_score': candidate_rating.get('rating', 0),
            'justification': candidate_rating.get('justification', ''),
            'rating_breakdown': candidate_rating
        },
        'interview_notes': {
            'technical_questions': interview_questions.get('technical_questions', generate_fallback_questions('technical', resume_parsing)),
            'experience_questions': interview_questions.get('experience_questions', generate_fallback_questions('experience', resume_parsing)),
            'behavioral_questions': interview_questions.get('behavioral_questions', generate_fallback_questions('behavioral', resume_evaluation)),
            'strengths_to_explore': resume_evaluation.get('strengths', []),
            'concerns_to_address': interview_questions.get('concerns_to_address', resume_evaluation.get('weaknesses', [])),
            'technical_background': resume_parsing.get('technicalSkills', {}),
            'work_experience': resume_parsing.get('workExperience', []),
            'education': resume_parsing.get('education', []) if isinstance(resume_parsing.get('education'), list) else [resume_parsing.get('education', {})] if resume_parsing.get('education') else [],
            'projects': resume_parsing.get('projects', []),
            'raw_notes': raw_response
        }
    }

def create_structured_from_text(evaluation_response):
    """
    When JSON parsing fails, return minimal structure with actual text content.
    """
    return {
        'evaluation_results': {
            'raw_evaluation': evaluation_response,
            'job_match_analysis': {
                'overall_assessment': evaluation_response
            }
        },
        'gaps_analysis': {
            'evaluation': {
                'analysis_text': evaluation_response
            }
        },
        'candidate_rating': {
            'overall_score': 0,
            'justification': evaluation_response
        },
        'interview_notes': {
            'raw_notes': evaluation_response
        }
    }

def extract_from_evaluation(resume_evaluation, aspect):
    """Extract assessment level from evaluation text for specific aspects"""
    overall_eval = resume_evaluation.get('overallEvaluation', '').lower()
    strengths = ' '.join(resume_evaluation.get('strengths', [])).lower()
    improvements = ' '.join(resume_evaluation.get('areasForImprovement', [])).lower()

    # Look for explicit mentions of the aspect in the evaluation
    if aspect.lower() in overall_eval or aspect.lower() in strengths:
        if 'excellent' in overall_eval or 'strong' in overall_eval:
            return 'High'
        elif 'good' in overall_eval or 'solid' in overall_eval:
            return 'Medium'
        else:
            return 'Low'

    # If mentioned in areas for improvement, it's likely lower
    if aspect.lower() in improvements:
        return 'Low'

    return 'Medium'  # Default neutral assessment

def parse_recommendations_from_text(overall_evaluation):
    """Parse actual recommendations from the evaluation text"""
    if not overall_evaluation:
        return []

    recommendations = []
    eval_lower = overall_evaluation.lower()

    # Look for common recommendation patterns in the actual text
    if 'benefit from' in eval_lower:
        # Extract text after "would benefit from"
        import re
        benefit_matches = re.findall(r'would benefit from ([^.]+)', eval_lower)
        recommendations.extend(benefit_matches)

    if 'should' in eval_lower:
        should_matches = re.findall(r'should ([^.]+)', eval_lower)
        recommendations.extend(should_matches)

    if 'recommend' in eval_lower:
        recommend_matches = re.findall(r'recommend ([^.]+)', eval_lower)
        recommendations.extend(recommend_matches)

    # Clean up recommendations
    cleaned_recommendations = [rec.strip() for rec in recommendations if rec.strip()]

    return cleaned_recommendations if cleaned_recommendations else ['See detailed evaluation for recommendations']

def extract_missing_skills_from_weaknesses(weaknesses):
    """Extract specific missing skills from weaknesses list"""
    missing_skills = []
    for weakness in weaknesses:
        if isinstance(weakness, str):
            weakness_lower = weakness.lower()
            if 'tensorflow' in weakness_lower or 'pytorch' in weakness_lower:
                missing_skills.append('Deep learning frameworks (TensorFlow/PyTorch)')
            if 'ai/ml' in weakness_lower and ('direct' in weakness_lower or 'experience' in weakness_lower):
                missing_skills.append('Direct AI/ML hands-on experience')
            if 'techniques' in weakness_lower and 'ai' in weakness_lower:
                missing_skills.append('AI/ML techniques and methodologies')
            if 'frameworks' in weakness_lower and 'deep' in weakness_lower:
                missing_skills.append('Deep learning frameworks')

    return missing_skills if missing_skills else weaknesses[:3]  # Fallback to first 3 weaknesses

def extract_skill_gaps(required_skills, candidate_skills):
    """Extract skill gaps by comparing required vs candidate skills"""
    gaps = []
    candidate_skill_text = str(candidate_skills).lower()

    for skill in required_skills:
        if isinstance(skill, str):
            skill_lower = skill.lower()
            if 'ai/ml' in skill_lower and 'ai' not in candidate_skill_text and 'machine learning' not in candidate_skill_text:
                gaps.append('AI/ML technologies and techniques')
            if 'deep learning' in skill_lower and 'tensorflow' not in candidate_skill_text and 'pytorch' not in candidate_skill_text:
                gaps.append('Deep learning experience')

    return gaps if gaps else required_skills[:2]  # Fallback to first 2 required skills

def assess_skill_level(resume_evaluation, aspect):
    """Extract realistic assessment level from evaluation content"""
    # Get the actual evaluation content
    strengths = resume_evaluation.get('strengths', [])
    weaknesses = resume_evaluation.get('weaknesses', [])
    overall_eval = resume_evaluation.get('overallAssessment', '').lower()

    # Convert lists to text for analysis
    strengths_text = ' '.join(strengths).lower() if isinstance(strengths, list) else str(strengths).lower()
    weaknesses_text = ' '.join(weaknesses).lower() if isinstance(weaknesses, list) else str(weaknesses).lower()

    # Look for aspect-specific mentions in strengths (High)
    if aspect.lower() in strengths_text:
        if any(word in strengths_text for word in ['strong', 'solid', 'good', 'meets']):
            return 'High'
        return 'Medium'

    # Look for aspect-specific mentions in weaknesses (Low)
    if aspect.lower() in weaknesses_text:
        if any(word in weaknesses_text for word in ['lacks', 'no', 'missing', 'limited']):
            return 'Low'
        return 'Medium'

    # Look in overall assessment
    if aspect.lower() in overall_eval:
        if any(word in overall_eval for word in ['strong', 'excellent', 'solid']):
            return 'High'
        elif any(word in overall_eval for word in ['lacks', 'limited', 'gap', 'missing']):
            return 'Low'
        return 'Medium'

    return 'Medium'  # Default neutral assessment

def extract_actual_recommendations(overall_assessment, weaknesses):
    """Extract actionable recommendations from evaluation content"""
    recommendations = []

    # Extract from overall assessment
    if overall_assessment:
        assessment_lower = overall_assessment.lower()
        if 'training' in assessment_lower or 'mentorship' in assessment_lower:
            recommendations.append('Provide AI/ML training and mentorship')
        if 'experience' in assessment_lower and 'gain' in assessment_lower:
            recommendations.append('Gain hands-on AI/ML project experience')
        if 'tensorflow' in assessment_lower or 'pytorch' in assessment_lower:
            recommendations.append('Learn deep learning frameworks (TensorFlow/PyTorch)')

    # Extract from weaknesses
    for weakness in weaknesses:
        if isinstance(weakness, str):
            weakness_lower = weakness.lower()
            if 'deep learning' in weakness_lower:
                recommendations.append('Gain experience with deep learning frameworks')
            if 'ai/ml' in weakness_lower and 'direct' in weakness_lower:
                recommendations.append('Work on AI/ML projects to gain direct experience')
            if 'techniques' in weakness_lower:
                recommendations.append('Study AI/ML techniques and methodologies')

    return recommendations if recommendations else ['Consider additional training in role-specific skills']

def generate_fallback_questions(question_type, data):
    """Generate fallback interview questions when agent doesn't provide them"""
    if question_type == 'technical':
        skills = data.get('technicalSkills', {})
        questions = []
        if skills.get('programming'):
            questions.append(f"Can you walk me through a challenging {', '.join(skills['programming'][:2])} project you've worked on?")
        if skills.get('data'):
            questions.append("How have you used data analysis tools in your previous projects?")
        return questions[:3] if questions else ["Tell me about your technical experience with the tools mentioned on your resume."]

    elif question_type == 'experience':
        work_exp = data.get('workExperience', [])
        if work_exp:
            recent_job = work_exp[0] if work_exp else {}
            company = recent_job.get('company', 'your current role')
            return [f"Tell me about your responsibilities at {company}.",
                   "What was your most challenging project and how did you handle it?"]
        return ["Tell me about your most relevant work experience."]

    elif question_type == 'behavioral':
        return ["How do you handle working with new technologies?",
               "Describe a time when you had to learn something quickly."]

    return ["Tell me more about your background."]

def create_initial_candidate_record(candidate_id, candidate_name, resume_key, resume_text):
    """
    Create initial candidate record in DynamoDB with processing status.
    """
    table_name = os.environ.get('CANDIDATES_TABLE')
    table = dynamodb.Table(table_name)

    candidate_item = {
        'id': candidate_id,
        'name': candidate_name,
        'resume_key': resume_key,
        'resume_text': resume_text,
        'status': 'processing',
        'created_at': datetime.utcnow().isoformat()
    }

    table.put_item(Item=candidate_item)
