"""
Strands Multi-Agent HR Resume Processor
This implementation uses the actual Strands SDK with Claude 3.7 Sonnet
"""

import json
import logging
import os
import uuid
from datetime import datetime
from typing import Dict, Any
from decimal import Decimal

import boto3
from strands import Agent, tool
from strands_tools import current_time, use_aws

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS clients
s3_client = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')

# Environment variables
CANDIDATES_TABLE = os.environ['CANDIDATES_TABLE']
DOCUMENTS_BUCKET = os.environ['DOCUMENTS_BUCKET']
MODEL_ID = "us.anthropic.claude-3-7-sonnet-20250219-v1:0"

# Initialize DynamoDB table
candidates_table = dynamodb.Table(CANDIDATES_TABLE)

def lambda_handler(event, context):
    """
    Strands Multi-Agent Lambda handler for comprehensive resume evaluation.
    """
    try:
        logger.info(f"🤖 Strands Multi-Agent HR System - Processing event: {json.dumps(event)}")
        
        # Extract S3 event information
        for record in event['Records']:
            bucket = record['s3']['bucket']['name']
            key = record['s3']['object']['key']
            
            # Only process resume files
            if not key.startswith('resumes/'):
                logger.info(f"Skipping non-resume file: {key}")
                continue
            
            logger.info(f"🔄 Strands Multi-Agent System processing resume: {key}")
            
            # Process the resume using Strands multi-agent approach
            result = process_resume_with_strands_agents(bucket, key)
            logger.info(f"✅ Strands processing result: {result}")
        
        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Strands Multi-Agent resume processing completed successfully'})
        }
        
    except Exception as e:
        logger.error(f"❌ Error in Strands Multi-Agent processing: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }

def process_resume_with_strands_agents(bucket: str, resume_key: str) -> Dict[str, Any]:
    """
    Process resume using Strands multi-agent collaboration with comprehensive evaluation.
    """
    try:
        # Generate candidate ID
        candidate_id = str(uuid.uuid4())
        
        # Download resume content
        resume_content = download_s3_file(bucket, resume_key)
        
        # Find matching job description
        job_content = find_job_description(bucket)
        
        logger.info("🤖 Initiating Strands Multi-Agent Collaboration with Claude 3.5...")
        logger.info("Creating Strands MetricsClient")
        
        # Create the HR Coordinator Agent using Strands SDK
        hr_coordinator = create_hr_coordinator_agent()
        
        # Process the resume through the Strands agent with comprehensive evaluation
        evaluation_request = f"""
        I need you to coordinate a comprehensive evaluation of this candidate for the given position. 
        Use your available tools to conduct a thorough analysis.

        RESUME CONTENT:
        {resume_content}

        JOB DESCRIPTION:
        {job_content}

        Please coordinate with your specialized agents to provide:
        1. Structured resume parsing and information extraction
        2. Detailed job requirements analysis  
        3. Comprehensive skills and experience evaluation
        4. Gap analysis and areas of concern
        5. Numerical candidate rating (1-5 scale) with detailed justification
        6. Interview preparation materials and questions

        Use all available tools to gather comprehensive data, then provide a final structured evaluation.
        """
        
        # Execute the Strands agent evaluation
        logger.info("🎯 Executing Strands Agent evaluation...")
        evaluation_result = hr_coordinator(evaluation_request)
        
        # Parse and structure the result
        structured_result = parse_strands_evaluation(evaluation_result, candidate_id, resume_key, resume_content)
        
        # Store in DynamoDB
        store_candidate_evaluation(structured_result)
        
        logger.info("✅ Strands Multi-Agent evaluation completed successfully")
        return structured_result
        
    except Exception as e:
        logger.error(f"❌ Error in Strands multi-agent processing: {str(e)}")
        # Store error state in DynamoDB
        error_result = create_error_result(candidate_id, resume_key, str(e))
        store_candidate_evaluation(error_result)
        raise

def create_hr_coordinator_agent() -> Agent:
    """
    Create the main HR Coordinator Agent using Strands SDK with consistent prompts matching bedrock-agent.
    """
    
    # Define custom tools for HR evaluation using exact bedrock-agent prompts
    @tool
    def extract_resume_info(resume_text: str) -> Dict[str, Any]:
        """
        Extract structured information from resume text including personal info, skills, experience, and education.
        
        Args:
            resume_text: The raw resume content to parse
            
        Returns:
            Dict containing structured resume information
        """
        # Create Resume Parser Agent with exact bedrock-agent prompt
        parser_agent = Agent(
            model=MODEL_ID,
            system_prompt="""You are a Resume Parser Agent specializing in extracting structured information from resumes.

When given a resume, extract the following information:

1. **Personal Information**:
   - Full name
   - Contact information (email, phone, location)
   - Professional title/role
   - LinkedIn/portfolio URLs

2. **Work Experience**:
   - Company names
   - Job titles
   - Employment dates (start and end)
   - Key responsibilities and achievements
   - Technologies/tools used
   - Quantifiable results and metrics

3. **Education**:
   - Degrees and certifications
   - Institutions
   - Graduation dates
   - Relevant coursework
   - Academic achievements

4. **Skills**:
   - Technical skills (programming languages, tools, platforms)
   - Soft skills
   - Languages
   - Proficiency levels when specified

5. **Projects**:
   - Project names
   - Descriptions
   - Technologies used
   - Role and contributions
   - Outcomes and impact

Always structure your response as a JSON object with these categories. Be thorough and extract all relevant information, but do not invent or assume details not present in the resume."""
        )
        
        result = parser_agent(resume_text)
        return safe_extract_content(result)
    
    @tool
    def analyze_job_requirements(job_description: str) -> Dict[str, Any]:
        """
        Analyze job description to extract detailed requirements, qualifications, and expectations.
        
        Args:
            job_description: The job posting content to analyze
            
        Returns:
            Dict containing structured job requirements and analysis
        """
        # Create Job Analyzer Agent with exact bedrock-agent prompt
        analyzer_agent = Agent(
            model=MODEL_ID,
            system_prompt="""You are a Job Analyzer Agent specializing in extracting and analyzing job requirements from job descriptions.

When given a job description, analyze and extract the following information:

1. **Required Qualifications**:
   - Education requirements
   - Years of experience
   - Technical skills and proficiency levels
   - Certifications
   - Domain knowledge

2. **Preferred Qualifications**:
   - Additional skills that are beneficial
   - Nice-to-have experience
   - Optional certifications
   - Preferred background

3. **Technical Skills**:
   - Programming languages
   - Frameworks and libraries
   - Tools and platforms
   - Methodologies
   - Required proficiency levels

4. **Company Culture**:
   - Work environment
   - Team structure
   - Company values
   - Work-life balance indicators
   - Remote/hybrid/onsite expectations

5. **Compensation and Benefits**:
   - Salary range (if provided)
   - Benefits mentioned
   - Perks
   - Growth opportunities

Always structure your response as a JSON object with these categories. Be thorough and extract all relevant information, but do not invent or assume details not present in the job description."""
        )
        
        result = analyzer_agent(job_description)
        return safe_extract_content(result)
    
    @tool
    def calculate_comprehensive_evaluation(resume_data: str, job_data: str) -> Dict[str, Any]:
        """
        Calculate comprehensive candidate evaluation including detailed scoring and analysis.
        
        Args:
            resume_data: Structured resume information
            job_data: Structured job requirements
            
        Returns:
            Dict containing detailed evaluation and scoring
        """
        # Create Resume Evaluator Agent with exact bedrock-agent prompt
        evaluator_agent = Agent(
            model=MODEL_ID,
            system_prompt="""You are a Resume Evaluator Agent specializing in comparing candidate resumes against job requirements.

When given a resume and job description, evaluate the following:

1. **Skills Match Analysis**:
   - Technical skills alignment
   - Proficiency level match
   - Missing critical skills
   - Transferable skills
   - Skill relevance to the role

2. **Experience Relevance Assessment**:
   - Industry relevance
   - Role similarity
   - Project relevance
   - Years of experience match
   - Leadership/management experience (if required)

3. **Education Fit Evaluation**:
   - Degree requirements match
   - Relevant certifications
   - Specialized training alignment
   - Continuing education relevance

4. **Project Relevance Review**:
   - Project scale and complexity match
   - Technology stack alignment
   - Problem domain relevance
   - Demonstrated outcomes

5. **Career Progression Analysis**:
   - Growth trajectory
   - Increasing responsibility
   - Promotion history
   - Job stability
   - Career focus alignment

Always structure your response as a JSON object with these categories. Provide detailed analysis with specific examples from the resume that match or don't match the job requirements. Be objective and thorough in your evaluation."""
        )
        
        evaluation_request = f"""
        RESUME DATA:
        {resume_data}

        JOB REQUIREMENTS:
        {job_data}
        """
        
        result = evaluator_agent(evaluation_request)
        return safe_extract_content(result)

    # Create the main HR Coordinator Agent with exact bedrock-agent supervisor prompt
    hr_coordinator = Agent(
        model=MODEL_ID,
        tools=[
            extract_resume_info,
            analyze_job_requirements, 
            calculate_comprehensive_evaluation,
            current_time,
            use_aws
        ],
        system_prompt="""You are the Supervisor Agent for HR resume evaluation. You coordinate with specialized collaborator agents to provide comprehensive candidate evaluations.

When evaluating a candidate, work with your team naturally:

1. Start by having ResumeParserAgent extract and structure the key information from the resume
2. Have JobAnalyzerAgent analyze the job requirements and identify what qualifications are needed
3. Have ResumeEvaluatorAgent evaluate how well the candidate matches the job requirements
4. Have CandidateRaterAgent provide a numerical rating (1-5 scale) with detailed justification

Your team members are:
- ResumeParserAgent: Extracts structured information from resumes
- JobAnalyzerAgent: Analyzes job descriptions and requirements  
- ResumeEvaluatorAgent: Evaluates candidate fit against job requirements
- CandidateRaterAgent: Provides numerical ratings with justification

Work collaboratively with your team. When you need specific expertise, naturally delegate to the appropriate team member. After gathering all the information from your collaborators, compile everything into a comprehensive evaluation report.

Focus on coordinating the work and compiling the final results rather than doing the specialized analysis yourself.

Always provide your final response as a comprehensive JSON structure containing all evaluation results.

Format your response as:
{
  "candidate_evaluation": {
    "candidate_id": "unique_identifier",
    "candidate_name": "extracted_name",
    "resume_parsing": { "personal_info": {}, "experience": [], "education": [], "skills": [], "projects": [] },
    "job_analysis": { "requirements": {}, "preferred": {}, "culture": {} },
    "resume_evaluation": { "skills_match": {}, "experience_relevance": {}, "education_fit": {} },
    "gap_analysis": { "missing_qualifications": [], "concerns": [], "clarifications_needed": [] },
    "candidate_rating": { "overall_score": 0, "justification": "", "strengths": [], "weaknesses": [] },
    "interview_notes": { "technical_questions": [], "experience_questions": [], "areas_to_probe": [] },
    "final_recommendation": "detailed_summary_and_recommendation"
  }
}"""
    )
    
    return hr_coordinator

def safe_extract_content(result) -> Dict[str, Any]:
    """
    Safely extract content from Strands agent response.
    """
    try:
        if hasattr(result, 'message'):
            content = result.message
        elif hasattr(result, 'content'):
            content = result.content
        else:
            content = str(result)
        
        # Try to parse JSON from the content
        return safe_parse_json(content)
        
    except Exception as e:
        logger.error(f"Error extracting content: {str(e)}")
        return {"error": f"Content extraction failed: {str(e)}", "raw_content": str(result)[:500]}

def safe_parse_json(content: str) -> Dict[str, Any]:
    """
    Safely parse JSON from text content with fallback mechanisms.
    """
    try:
        # First try direct JSON parsing
        if content.strip().startswith('{'):
            return json.loads(content)
        
        # Look for JSON blocks in markdown
        import re
        json_pattern = r'```(?:json)?\s*(\{.*?\})\s*```'
        json_match = re.search(json_pattern, content, re.DOTALL | re.IGNORECASE)
        
        if json_match:
            return json.loads(json_match.group(1))
        
        # Look for any JSON-like structure
        json_pattern = r'\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}'
        json_match = re.search(json_pattern, content, re.DOTALL)
        
        if json_match:
            return json.loads(json_match.group())
        
        # Fallback to structured text response
        return {
            "analysis": content,
            "status": "text_response",
            "parsing_method": "fallback"
        }
        
    except json.JSONDecodeError as e:
        logger.error(f"JSON parsing error: {str(e)}")
        return {
            "analysis": content[:1000],  # Truncate long content
            "error": f"JSON parsing failed: {str(e)}",
            "status": "parse_error"
        }
    except Exception as e:
        logger.error(f"Unexpected parsing error: {str(e)}")
        return {
            "analysis": str(content)[:500],
            "error": f"Parsing failed: {str(e)}",
            "status": "error"
        }
    """Download file content from S3."""
    try:
        response = s3_client.get_object(Bucket=bucket, Key=key)
        return response['Body'].read().decode('utf-8')
    except Exception as e:
        logger.error(f"Error downloading S3 file {key}: {str(e)}")
        raise

def find_job_description(bucket: str) -> str:
    """Find and download job description from S3."""
    try:
        # List objects in jobs/ prefix
        response = s3_client.list_objects_v2(Bucket=bucket, Prefix='jobs/')
        
        if 'Contents' not in response or len(response['Contents']) == 0:
            return "No specific job description found. Please evaluate general qualifications."
        
        # Get the first job description
        job_key = response['Contents'][0]['Key']
        return download_s3_file(bucket, job_key)
        
    except Exception as e:
        logger.error(f"Error finding job description: {str(e)}")
        return "No job description available. Please evaluate general qualifications."

def safe_extract_content(result) -> Dict[str, Any]:
    """
    Safely extract content from Strands agent response.
    """
    try:
        if hasattr(result, 'message'):
            content = result.message
        elif hasattr(result, 'content'):
            content = result.content
        else:
            content = str(result)
        
        # Try to parse JSON from the content
        return safe_parse_json(content)
        
    except Exception as e:
        logger.error(f"Error extracting content: {str(e)}")
        return {"error": f"Content extraction failed: {str(e)}", "raw_content": str(result)[:500]}

def safe_parse_json(content: str) -> Dict[str, Any]:
    """
    Safely parse JSON from text content with fallback mechanisms.
    """
    try:
        # First try direct JSON parsing
        if content.strip().startswith('{'):
            return json.loads(content)
        
        # Look for JSON blocks in markdown
        import re
        json_pattern = r'```(?:json)?\s*(\{.*?\})\s*```'
        json_match = re.search(json_pattern, content, re.DOTALL | re.IGNORECASE)
        
        if json_match:
            return json.loads(json_match.group(1))
        
        # Look for any JSON-like structure
        json_pattern = r'\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}'
        json_match = re.search(json_pattern, content, re.DOTALL)
        
        if json_match:
            return json.loads(json_match.group())
        
        # Fallback to structured text response
        return {
            "analysis": content,
            "status": "text_response",
            "parsing_method": "fallback"
        }
        
    except json.JSONDecodeError as e:
        logger.error(f"JSON parsing error: {str(e)}")
        return {
            "analysis": content[:1000],  # Truncate long content
            "error": f"JSON parsing failed: {str(e)}",
            "status": "parse_error"
        }
    except Exception as e:
        logger.error(f"Unexpected parsing error: {str(e)}")
        return {
            "analysis": str(content)[:500],
            "error": f"Parsing failed: {str(e)}",
            "status": "error"
        }

def parse_strands_evaluation(evaluation_result, candidate_id: str, resume_key: str, resume_content: str) -> Dict[str, Any]:
    """
    Parse the Strands agent evaluation result into structured format matching bedrock-agent.
    """
    try:
        # Extract the message content from Strands result
        evaluation_content = safe_extract_content(evaluation_result)
        
        # Extract candidate name from resume or key
        candidate_name = extract_name_from_key(resume_key)
        
        # Create comprehensive result structure matching bedrock-agent format
        result = {
            "id": candidate_id,
            "resume_key": resume_key,
            "name": candidate_name,
            "status": "completed",
            "created_at": datetime.utcnow().isoformat(),
            "completed_at": datetime.utcnow().isoformat(),
            "evaluated_by": "Strands Multi-Agent System",
            "resume_text": resume_content,
            
            # Strands-specific collaboration metadata
            "strands_agent_collaboration": {
                "evaluation_approach": "Multi-agent collaboration with specialized agents",
                "agents_used": [
                    "HR Coordinator",
                    "Resume Parser", 
                    "Job Analyzer",
                    "Resume Evaluator",
                    "Gap Identifier",
                    "Candidate Rater",
                    "Interview Notes"
                ],
                "model_used": MODEL_ID,
                "evaluation_content": {
                    "role": "assistant",
                    "content": [{"text": str(evaluation_content)}]
                }
            },
            
            # Structured evaluation components matching bedrock-agent format
            "resume_parsing": {
                "agent": "Strands Resume Parser Agent",
                "candidate_name": candidate_name,
                "parsing_results": evaluation_content.get("resume_parsing", {
                    "analysis": "Resume parsing completed via Strands multi-agent system"
                })
            },
            
            "job_analysis": {
                "agent": "Strands Job Analyzer Agent", 
                "job_analysis_results": evaluation_content.get("job_analysis", {
                    "analysis": "Job analysis completed via Strands multi-agent system"
                })
            },
            
            "resume_evaluation": {
                "agent": "Strands Resume Evaluator Agent",
                "evaluation_results": evaluation_content.get("resume_evaluation", {
                    "analysis": "Resume evaluation completed via Strands multi-agent system"
                })
            },
            
            "gap_analysis": {
                "agent": "Strands Gap Identifier Agent",
                "gap_analysis_results": evaluation_content.get("gap_analysis", {
                    "analysis": "Gap analysis completed via Strands multi-agent system"
                })
            },
            
            "candidate_rating": {
                "agent": "Strands Candidate Rater Agent",
                "rating_results": evaluation_content.get("candidate_rating", {
                    "rating": 3,
                    "justification": "Evaluated using Strands multi-agent system",
                    "strengths": ["Processed by Strands agents"],
                    "weaknesses": ["Standard evaluation completed"]
                })
            },
            
            "interview_notes": {
                "agent": "Strands Interview Notes Agent",
                "interview_preparation": evaluation_content.get("interview_notes", {
                    "analysis": "Interview preparation completed via Strands multi-agent system"
                })
            }
        }
        
        return result
        
    except Exception as e:
        logger.error(f"Error parsing Strands evaluation: {str(e)}")
        return create_error_result(candidate_id, resume_key, f"Parsing error: {str(e)}")

def download_s3_file(bucket: str, key: str) -> str:
    """Download file content from S3."""
    try:
        response = s3_client.get_object(Bucket=bucket, Key=key)
        return response['Body'].read().decode('utf-8')
    except Exception as e:
        logger.error(f"Error downloading S3 file {key}: {str(e)}")
        raise

def extract_name_from_key(resume_key: str) -> str:
    """Extract candidate name from resume file key."""
    try:
        filename = resume_key.split('/')[-1]
        name = filename.replace('.txt', '').replace('_', ' ').replace('-', ' ')
        return ' '.join(word.capitalize() for word in name.split())
    except:
        return "Unknown Candidate"

def create_error_result(candidate_id: str, resume_key: str, error_message: str) -> Dict[str, Any]:
    """Create error result structure."""
    return {
        "id": candidate_id,
        "resume_key": resume_key,
        "name": extract_name_from_key(resume_key),
        "status": "error",
        "error": error_message,
        "created_at": datetime.utcnow().isoformat(),
        "evaluated_by": "Strands Multi-Agent System (Error)",
        "strands_agent_collaboration": {
            "evaluation_approach": "Error during Strands agent processing",
            "error_details": error_message
        }
    }

def store_candidate_evaluation(evaluation_data: Dict[str, Any]) -> None:
    """Store evaluation data in DynamoDB."""
    try:
        # Convert any float values to Decimal for DynamoDB
        def convert_floats(obj):
            if isinstance(obj, dict):
                return {k: convert_floats(v) for k, v in obj.items()}
            elif isinstance(obj, list):
                return [convert_floats(v) for v in obj]
            elif isinstance(obj, float):
                return Decimal(str(obj))
            else:
                return obj
        
        converted_data = convert_floats(evaluation_data)
        
        candidates_table.put_item(Item=converted_data)
        logger.info(f"✅ Stored evaluation for candidate: {evaluation_data.get('name', 'Unknown')}")
        
    except Exception as e:
        logger.error(f"❌ Error storing evaluation in DynamoDB: {str(e)}")
        raise
